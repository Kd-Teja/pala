
function firstcomponent(){
     return (
        <div>
           <div>
             <nav>
                <ul className="nav">
                  <li>ALL PRODUCTS</li>
                  <li>TOPWEAR</li>
                  <li>BOTTOMWEAR</li>
                  <li>FOOTWEAR</li>
                  <li>ESSENTIALS</li>
                  <li>COLLABORATIONS</li>
                  <i class="fa-solid fa-magnifying-glass"></i> 
                  <input type="text" name="SEARCH" placeholder="search here"/>
                </ul>
             </nav>
           </div>
        </div>
     )
     
}
export default firstcomponent 