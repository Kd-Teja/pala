import { useEffect, useState } from "react"
import { useLocation } from "react-router-dom"

function Singleproductpage(){
    const location=useLocation()
     const{id} =location.state || null
    const[product,setproduct]=useState({})
    const singleproduct= async ()=>{
        if(id){
            let response=await fetch(`https://fakestoreapi.com/products/${id}`)
            let data=await response.json()
            setproduct(data)

        }
    }
    useEffect(()=>{
        singleproduct()
    })
    return(
        <div>
            <h1>productpage</h1>
            <h1>{}</h1>
        </div>
    )
}
export default Singleproductpage