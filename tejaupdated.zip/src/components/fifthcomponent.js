import { useEffect, useState } from "react"
import { Link } from "react-router-dom"

function Sai()
{
    const[read,getread]=useState([])
    
   

    const[filter,setfilterdata]=useState([])
    useEffect(() =>{
        fetch('https://fakestoreapi.com/products/categories')
            .then(res=>res.json())
            .then(json=>console.log(json))
    },[])
    const apicatagories=async ()=>{
        const url=await  fetch('https://fakestoreapi.com/products/categories')
        let out=await url.json()
        console.log(out)
        getread(out)

    }
    useEffect(() =>{
        apicatagories()
    },[])
   
   
   
   useEffect(() =>{
    fetch('https://fakestoreapi.com/products/category/jewelery')
        .then(res=>res.json())
        .then(json=>console.log(json))
},[])

const apijewelery = async(teja) =>{

   let url = await fetch(`https://fakestoreapi.com/products/category/${teja}`)

   let out2 = await url.json()
   setfilterdata(out2)
   console.log(out2)

}




   return(
    <div>
      <Link to='/'>  <h1>

            welocome
        </h1>
        </Link>
        <div style={{display:"grid", gridTemplateColumns:"300px 300px 300px 300px"}}>
        {
          

            read.map((teja,index) =>{
                return(
                    <div key={index}>
                   <button onClick={()=>apijewelery(teja)}>
                      {
                        teja
                      }
                   </button>
                  
                    </div>
                )
            })
          

        }
        </div>
        <div>
        {
           
            filter.map((teja,index)=>{
                return (
                    <Link to="/Productdetails" state={{id:teja.id}}>
                <div  key={index} class="container text-center" >
                    
                    {
                    
                       <div>
                         <p>{teja.category}</p>
                         <h1>{teja.id}</h1>
                         <p>{teja.description}</p>
                         <img src={teja.image}/>
                         <h2>{teja.price}</h2>
                         
                        </div>
                       
                    }
                </div>
                </Link>
                )
            })
        }
        </div>
    </div>
   )
}
export default Sai