import Sai from "../images/body.png"

function secondcomponent(){
    return (
        <div>
            <div className="second">
            <img src={Sai} alt="Company Logo" />
               
            <h1>VIEW ALL</h1>
            <h2>PRODUCTS</h2>
            </div> 
        </div>
    )
}
export default secondcomponent