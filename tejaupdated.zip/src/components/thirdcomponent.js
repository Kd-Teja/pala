function thirdcomponent(){
    return (
        <div>
        
            <div className="third">
                <ul>
                    <div className="items">
                    <li>Blazzer</li>
                    <li>Shoes</li>
                    <li>Jackets</li>
                    <li>Shirts</li>
                    <li>Sweaters</li>
                    <li>show more</li>
                    </div>
                </ul>
            </div>
        </div>
    )
}
export default thirdcomponent
// Blazer
// (3)
// check icon
// Jackets
// (33)
// check icon
// Shirts
// (458)
// check icon
// Sweaters
// (25)
// check icon
// Sweatshirts
// (76)
// Show more
// Type